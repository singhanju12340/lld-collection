package interview.inmemory_cache_writePolicy;

/**
 * @author anju
 * @created on 25/02/25 and 7:29 PM
 */
public class Configs {
    public static final Integer TTL = 100;
    public static final Integer cacheSize = 2;
}
