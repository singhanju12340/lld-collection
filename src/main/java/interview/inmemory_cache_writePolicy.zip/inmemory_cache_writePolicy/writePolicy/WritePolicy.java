package interview.inmemory_cache_writePolicy.writePolicy;

/**
 * @author anju
 * @created on 12/03/25 and 11:01 PM
 */
public enum WritePolicy {
    WRITE_THROUGH,
    WRITE_BACK
}
