package com.tekion.aec.cp.imsjobs.controller.machineCode.loggerSystem.sink;

import java.util.LinkedHashSet;

/**
 * @author anju
 * @created on 01/02/25 and 10:54 AM
 */
public class DBSinkStore implements SinkProcessor{

    LinkedHashSet<String> data;  // queue maintaining data ordering


    // assumed message is stored in DB
    private static DBSinkStore dbSinkStore;

    public  static DBSinkStore getInstance(){
        if(dbSinkStore == null)
        {
            dbSinkStore = new DBSinkStore();
            dbSinkStore.data = new LinkedHashSet<>();
        }
        return dbSinkStore;
    }


    @Override
    public void add(String message) {
        // run  multiple  threads to connect to DB and store

        System.out.println("DB sink message " + message);
        this.dbSinkStore.data.add(message);  // this add message to queue
    }

    @Override
    public void clear() {
        this.dbSinkStore.data = new LinkedHashSet<>();
    }

    @Override
    public void close() {
        dbSinkStore = null;
    }
}
