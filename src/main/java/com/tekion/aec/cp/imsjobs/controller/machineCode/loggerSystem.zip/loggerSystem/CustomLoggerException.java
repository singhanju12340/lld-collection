package com.tekion.aec.cp.imsjobs.controller.machineCode.loggerSystem;

/**
 * @author anju
 * @created on 01/02/25 and 11:27 AM
 */
public class CustomLoggerException extends RuntimeException{

    public CustomLoggerException(String message) {
        super(message);
    }
}
