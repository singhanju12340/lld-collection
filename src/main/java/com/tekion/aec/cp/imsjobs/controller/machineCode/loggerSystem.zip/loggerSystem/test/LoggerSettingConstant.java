package com.tekion.aec.cp.imsjobs.controller.machineCode.loggerSystem.test;

/**
 * @author anju
 * @created on 01/02/25 and 11:17 AM
 */
public class LoggerSettingConstant {

    public static String logLevel = "INFO";
    public static String sinkType = "DB"; // DB/FILE/CONSOLE
    public static String serviceNameSpace = "TestService";


}
